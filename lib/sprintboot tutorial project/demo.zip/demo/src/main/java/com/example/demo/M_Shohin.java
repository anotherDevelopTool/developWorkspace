package com.example.demo;
import javax.persistence.*;
import java.util.Date;

@Entity
public class M_Shohin {

    // "customer_seq" is Oracle sequence name.
    @Id
    @Column(name = "HINBAN")
    String hinban;


    //getters and setters, contructors
}