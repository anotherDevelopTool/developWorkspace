package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.TransactionDefinition;
import org.springframework.transaction.TransactionStatus;
import org.springframework.transaction.annotation.EnableTransactionManagement;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.transaction.support.DefaultTransactionDefinition;

import javax.sql.DataSource;
import java.util.stream.Stream;

@SpringBootApplication
@EnableTransactionManagement
//@Component
public class DemoApplication implements CommandLineRunner {
	@Autowired
	DataSource dataSource;
	@Autowired
	JdbcTemplate jdbcTemplate;
	@Autowired
	PlatformTransactionManager txManager;

	@Autowired
	MShohinRepository customerRepository;

	@Transactional(propagation = Propagation.REQUIRES_NEW, timeout = 1)
	public void testWithTransaction() throws Exception{
		jdbcTemplate.update("update m_shohin set upd_dt=sysdate where hinban ='000002'");
		Thread.sleep(5*1000);
	}

	public void test() throws Exception{
		DefaultTransactionDefinition txDefinition = new DefaultTransactionDefinition();
		txDefinition.setPropagationBehavior(TransactionDefinition.PROPAGATION_REQUIRED);
		txDefinition.setTimeout(1);
		TransactionStatus txStatus =  null;
		txStatus = txManager.getTransaction(txDefinition);
		jdbcTemplate.query("select hinban from m_shohin where rownum <10",(r,i)->{
			System.out.println(r.getString("hinban"));
			return null;
		});
		jdbcTemplate.update("update m_shohin set upd_dt=sysdate where hinban ='000002'");
		Thread.sleep(5*1000);

		txManager.commit(txStatus);

	}
	@Transactional(propagation = Propagation.REQUIRES_NEW, timeout = 5)
	public void test_jpa() throws Exception{
		jdbcTemplate.update("update m_shohin set upd_dt=sysdate where hinban ='000002'");
		Thread.sleep(5*1000);
		System.out.println("-----------------------test_jpa----------------------------sleep");
		//会在这个位置Transaction timed out
		try (Stream<String> stream = customerRepository.findByEmailReturnStream()) {
			stream.forEach(x -> System.out.println(x));
		}
		Thread.sleep(5*1000);
		System.out.println("-----------------------test_jpa----------------------------sleep");
	}

	//并不会因为没有更新数据库而放弃检查timeout
	@Transactional(propagation = Propagation.REQUIRES_NEW, timeout = 5)
	public void test_jpa_senario_02() throws Exception{
		try (Stream<String> stream = customerRepository.findByEmailReturnStream()) {
			stream.forEach(x -> System.out.println(x));
		}
		Thread.sleep(5*1000);
		System.out.println("-----------------------test_jpa----------------------------sleep");
		//会在这个位置Transaction timed out,并不会因为没有更新数据库而放弃检查timeout
		try (Stream<String> stream = customerRepository.findByEmailReturnStream()) {
			stream.forEach(x -> System.out.println(x));
		}
		Thread.sleep(5*1000);
		System.out.println("-----------------------test_jpa----------------------------sleep");
	}
	//JpaTransactionManager只在发行stmt时才去check是否timeout耗尽，而不会在commit的是否时间耗尽.这个会导致事务开始到结束时会受其他CPU处理耗时过长而过长
	//这个和atomikos的行为不太一致，atomikos会在commit时check
	@Transactional(propagation = Propagation.REQUIRES_NEW, timeout = 7)
	public void test_jpa_senario_03() throws Exception{
		jdbcTemplate.update("update m_shohin set upd_dt=sysdate where hinban ='000002'");
		Thread.sleep(5*1000);
		System.out.println("-----------------------test_jpa----------------------------sleep");
		jdbcTemplate.update("update m_shohin set upd_dt=sysdate where hinban ='000002'");
		Thread.sleep(5*1000);
		System.out.println("-----------------------test_jpa----------------------------sleep");
		//在这个位置timeout
		jdbcTemplate.update("update m_shohin set upd_dt=sysdate where hinban ='000002'");
		Thread.sleep(5*1000);
		System.out.println("-----------------------test_jpa----------------------------sleep");
	}
	public static void main (String[] args)  throws Exception{
		ConfigurableApplicationContext ctx = SpringApplication.run(DemoApplication.class, args);
		DemoApplication demoApplication = (DemoApplication) ctx.getBean("demoApplication");
////		demoApplication.test();
////		System.out.println("----------------------test-----------------------------");
////		demoApplication.testWithTransaction();
		System.out.println("-----------------------test_jpa----------------------------start");
//		demoApplication.test_jpa();
		demoApplication.test_jpa_senario_03();
		System.out.println("-----------------------test_jpa----------------------------end");


	}

	@Override
	public void run(String... args) throws Exception {
//		test();
//		testWithTransaction();
//		test_jpa();
	}
}
