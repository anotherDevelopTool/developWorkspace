package com.example.demo;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import java.util.stream.Stream;

public interface MShohinRepository extends CrudRepository<M_Shohin, Long> {

    // custom query example and return a stream
    @Query("select hinban from M_Shohin where rownum < 10")
    Stream<String> findByEmailReturnStream();

}