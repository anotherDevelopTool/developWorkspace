在有特殊场合，需要手动进行实物的提交。如DB提交后再发送MQ等场景。在api的编写时可以分割service方法，一个标注事物，一个非事物的方式可以解决这个问题。但是在SpringBatch里。针对Step的事物控制，要么有事物，要么无事物，不能简单在一个chunk内提前DB提交后再继续做发送MQ的

处理。需要类似如下的手法（当然通过listener的afterchuck等也能到到同样的效果），或者使用transactional标签，并设置为Propagation.REQUIRES_NEW属性



另外稍微高阶的方式是使用 synchronazationManager的回调方式

使用手动集成transactioninterceptor到特定类方法的方式



另外通过代码来验证事物的timeout是app来控制的，还是jdbc driver? database engine?.

JdbcTransactionManager不能控制timeout

JpaTransactionManager能够控制timeout

JtaTransactionManager能够控制timeout

(rba项目内实质上有下面类来控制）
atomikosTransactionManager
demo.zip

db.properties

# -----------------------
# JTA TRANSACTION CONFIGURATION (LOCAL)
# -----------------------
# timeout : seconds
db.jta.transaction_timeout 9
db.jta.transaction_force_shutdown false
-Dcom.atomikos.icatch.max_timeout=120 -Dcom.atomikos.icatch.default_jta_timeout=140

com.atomikos.icatch.imp.TransactionServiceImp

private CoordinatorImp createCC ( RecoveryCoordinator adaptor ,
        String root , boolean checkOrphans , boolean heuristic_commit ,
        long timeout )
{
    CoordinatorImp cc = null;

    if (maxTimeout_ > 0 &&  timeout > maxTimeout_ ) {
        timeout = maxTimeout_;
        //FIXED 20188
        LOGGER.logWarning ( "Attempt to create a transaction with a timeout that exceeds maximum - truncating to: " + maxTimeout_ );
    }

    synchronized ( shutdownSynchronizer_ ) {
        // check if shutting down -> do not allow new coordinator objects
        // to be added, so that shutdown will eventually succeed.
        if ( shutdownInProgress_ )
            throw new IllegalStateException ( "Server is shutting down..." );

        if ( otsOverride_ ) {
            // forced OTS mode; we do NEVER check orphans in this case
            checkOrphans = false;
        }
        cc = new CoordinatorImp ( root, adaptor,
                heuristic_commit, timeout,
                checkOrphans , single_threaded_2pc_ );

        recoverymanager_.register ( cc );

        // now, add to root map, since we are sure there are not too many active txs
        synchronized ( getLatch ( root.intern () ) ) {
            rootToCoordinatorMap_.put ( root.intern (), cc );
        }
        startlistening ( cc );
    }

    return cc;
}

每次启动事物的时候都会出力下面的日志
2021-10-29 10:32:34.298 [http-nio-18001-exec-1] WARN | c.a.icatch.imp.TransactionServiceImp[Slf4jLogger.java:24] - Attempt to create a transaction with a timeout that exceeds maximum - truncating to: 120 

